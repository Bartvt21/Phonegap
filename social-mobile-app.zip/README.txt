A Pen created at CodePen.io. You can find this one at https://codepen.io/yousefsami/pen/JbyaqQ.

 social mobile application with contact list , chats list , activity , setting and send message form and support mobile touch events